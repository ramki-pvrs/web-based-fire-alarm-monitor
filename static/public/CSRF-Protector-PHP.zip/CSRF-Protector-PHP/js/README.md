Compatiblity with different browsers
===================================
**OS: `windows`**<br>


 Cases               | IE (Win)   | Opera | Chrome | Mozilla | Safari 
 ------------------  | ------- | ----- | ------ | ------- | ------ 
 XHR wrapping        | ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)     | ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)      |     ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   |    ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)     | ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)
 HTML dom-0 wrapping |   ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   |    ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   |    ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)    |     ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)    | ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)
 HTML dom-2 wrapping |   ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)    |    ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   |   ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)     |      ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   | ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png) 
 URL rewriting       |   ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   |   ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)    |     ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)   |    ![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)     |![yes](https://cdn3.iconfinder.com/data/icons/fatcow/32/accept.png)

<pre>Note: Missing tick means, this has not yet been implemented or tested</pre>


