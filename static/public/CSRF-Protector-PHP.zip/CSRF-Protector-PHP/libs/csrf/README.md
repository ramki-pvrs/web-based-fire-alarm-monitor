Placeholder for **CSRF Protector - php library**
=====================================================

**Dependency:** `None`<br>
**Configuration-File:** `../config.php`<br>
**Configuration-Format:** `PHP ARRAY`<br>
